#!/bin/bash

python3 setup.py sdist --formats=zip
